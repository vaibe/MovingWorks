﻿using FrameBaseB_Web;
using FrameBaseB_Web.PagesUtilities;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace FrameBaseC_Tests.FeatureSteps
{
    [Binding]
    public class ContactsFeatureSteps
    {
        [Given(@"I am at the QA Works Contact page")]
        public void GivenIAmAtTheQAWorksContactPage()
        {
            
        }

        [When(@"I fill in the mandatory details in the form (.*), (.*) and (.*)")]
        public void WhenIFillInTheMandatoryDetailsInTheForm(string name, string email, string message)
        {
            PageInstantiator.ContactsPage.EnterContactName(name);
            PageInstantiator.ContactsPage.EnterContactEmail(email);
            PageInstantiator.ContactsPage.EnterMessage(message);
        }

        [When(@"I press Send button")]
        public void WhenIPressSendButton()
        {
            PageInstantiator.ContactsPage.ClickSend();
        }

        [Then(@"my message is sent")]
        public void ThenMyMessageIsSent()
        {
            
        }

        [When(@"I leave the Name field blank")]
        public void WhenILeaveTheNameFieldBlank()
        {

        }

        [When(@"I enter an email address in the Email field as ""(.*)""")]
        public void WhenIEnterAnEmailAddressInTheEmailFieldAs(string email)
        {
            PageInstantiator.ContactsPage.EnterContactEmail(email);
        }

        [When(@"I enter the message in the Message field as ""(.*)""")]
        public void WhenIEnterTheMessageInTheMessageFieldAs(string message)
        {
            PageInstantiator.ContactsPage.EnterMessage(message);
        }
        
        [Then(@"the ""(.*)"" validation message is displayed for the Name field I left blank")]
        public void ThenTheValidationMessageIsDisplayedForTheNameFieldILeftBlank(string validationMessage)
        {
            PollingWaiter.ElementVisible(By.XPath("//div[@id='ContactNameBox']/span"));
            Assert.AreEqual(validationMessage, PageInstantiator.ContactsPage.GetNameError(), "Validation not present on the Name field");
        }


        [When(@"I enter a name in the Name field as ""(.*)""")]
        public void WhenIEnterANameInTheNameFieldAs(string contactName)
        {
            PageInstantiator.ContactsPage.EnterContactName(contactName);
        }

        [When(@"I leave the Email field blank")]
        public void WhenILeaveTheEmailFieldBlank()
        {

        }       

        [Then(@"the ""(.*)"" validation message is displayed for the Email field I left blank")]
        public void ThenTheValidationMessageIsDisplayedForTheEmailFieldILeftBlank(string emailValidationMessage)
        {
            PollingWaiter.ElementVisible(By.XPath("//div[@id='ContactEmailBox']/span[2]"));
            Assert.AreEqual(emailValidationMessage, PageInstantiator.ContactsPage.GetEmailError(), "Validation not present on the Email field");
        }

        [Then(@"I get a validation message for the invalid Email address entered")]
        public void ThenIGetAValidationMessageForTheInvalidEmailAddressEntered()
        {
            Assert.AreEqual("Invalid Email Address", PageInstantiator.ContactsPage.GetEmailError(), "Validation not present on the Email field");
        }

        [Then(@"the ""(.*)"" validation message is displayed for the invalid Email address entered")]
        public void ThenTheValidationMessageIsDisplayedForTheInvalidEmailAddressEntered(string invalidEmailMessage)
        {           
            Assert.AreEqual(invalidEmailMessage, PageInstantiator.ContactsPage.GetEmailError(), "Validation not present on the Email field");
        }


        [When(@"I enter an invalid email address in the Email field as ""(.*)""")]
        public void WhenIEnterAnInvalidEmailAddressInTheEmailFieldAs(string email)
        {
            PageInstantiator.ContactsPage.EnterContactEmail(email);
        }        

        [Then(@"the ""(.*)"" validation message is displayed for the Message field I left blank")]
        public void ThenTheValidationMessageIsDisplayedForTheMessageFieldILeftBlank(string messageValidation)
        {
            PollingWaiter.ElementVisible(By.XPath("//div[@id='ContactMessageBox']/span"));
            Assert.AreEqual(messageValidation, PageInstantiator.ContactsPage.GetMessageError(), "Validation not present on the Message field");
        }


        [When(@"I leave the Message field blank")]
        public void WhenILeaveTheMessageFieldBlank()
        {

        }

        [Then(@"the ""(.*)"" acknowledgement message is displayed")]
        public void ThenTheAcknowledgementMessageIsDisplayed(string acknowledgement)
        {            
            Assert.AreEqual(acknowledgement, PageInstantiator.ContactsPage.GetMessageError(), "Message sent acknowledgement is not displayed");
        }



    }
}

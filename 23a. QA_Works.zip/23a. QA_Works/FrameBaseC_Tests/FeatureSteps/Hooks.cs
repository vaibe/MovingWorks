﻿using FrameBaseB_Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace FrameBaseC_Tests.FeatureSteps
{
    [Binding]
    public class Hooks : TestsOperations
    {
        [BeforeScenario()]
        public void SetUpTest()
        {
            TestSetup();
        }

        [AfterScenario]
        public void CleanUpTest()
        {
            TestCleanUp();
        }
    }
}

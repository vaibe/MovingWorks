﻿using FrameBaseB_Web.Pages;
using FrameBaseB_Web.PagesUtilities;

namespace FrameBaseB_Web
{
    public class PageInstantiator
    {
        // <summary>
        /// Return instance of PageTester object with elements initialised
        /// </summary>
        public static PagesTester HeaderPage
        {
            get
            {
                return ElementsInitialiser.PageElementsIn<PagesTester>();
            }
        }

        // <summary>
        /// Return instance of ContactsPage object with elements initialised
        /// </summary>
        public static P01_ContactsPage ContactsPage
        {
            get
            {
                return ElementsInitialiser.PageElementsIn<P01_ContactsPage>();
            }
        }

        

    }
}
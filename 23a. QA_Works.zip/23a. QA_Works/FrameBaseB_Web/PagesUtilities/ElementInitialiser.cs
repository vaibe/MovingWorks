﻿using FrameBaseB_Web;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace FrameBaseB_Web.PagesUtilities
{
    public class ElementsInitialiser
    {
        private static IWebDriver _driver;

        public static T PageElementsIn<T>() where T : new()
        {
            _driver = TestsOperations.driver;
            var page = new T();
            PageFactory.InitElements(_driver, page);
            return page;
        }
    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FrameBaseB_Web.PagesUtilities
{
    public class PollingWaiter
    {
        public static void ElementVisible(By ByLocator)
        {
            IWebElement Element = new WebDriverWait(TestsOperations.driver,
                TimeSpan.FromSeconds(30))
                .Until(ExpectedConditions.ElementIsVisible(ByLocator));
        }
    }
}

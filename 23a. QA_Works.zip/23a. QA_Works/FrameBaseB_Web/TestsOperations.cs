﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace FrameBaseB_Web
{   
 
    public abstract class TestsOperations
    {
        internal static IWebDriver driver;

        /// <summary>
        /// Begin Execution of tests
        /// </summary>
        public void TestSetup()
        {
            driver = new ChromeDriver();            
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
            driver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("http://www.qaworks.com/contact.aspx");
        }

        /// <summary>
        /// Finish Execution of tests
        /// </summary>
        public void TestCleanUp()
        {
            driver.Manage().Cookies.DeleteAllCookies();
            if (driver != null)
            {
                driver.Quit();
            }
        }    

    }
}

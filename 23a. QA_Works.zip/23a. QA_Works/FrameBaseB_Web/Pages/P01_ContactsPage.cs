﻿using FrameBaseB_Web.PagesUtilities;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FrameBaseB_Web.Pages
{
    public class P01_ContactsPage
    {
        [FindsBy(How = How.XPath, Using = "//div[@id='ContactHead']/h1")]
        protected IWebElement ContactPageHeading { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactNameBox']/input[1]")]
        protected IWebElement input_Name { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactNameBox']/span")]
        protected IWebElement msg_Name { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactEmailBox']/input")]
        protected IWebElement input_Email { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactEmailBox']/span[2]")]
        protected IWebElement msg_Email { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactMessageBox']/textarea")]
        protected IWebElement input_Message { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactMessageBox']/span")]
        protected IWebElement msg_Message { get; set; }

        [FindsBy(How = How.XPath, Using = "//div[@id='ContactSend']/input")]
        protected IWebElement btn_Send { get; set; }

        /// <summary>
        /// Enters text into the Name field
        /// </summary>
        public void EnterContactName(string contactName)
        {
            input_Name.SendKeys(contactName);
        }

        /// <summary>
        /// Returns Name field validation message
        /// </summary>
        public string GetNameError()
        {            
            return msg_Name.Text;
        }

        /// <summary>
        /// Enters email address into the Email field
        /// </summary>
        public void EnterContactEmail(string contactEmail)
        {
            input_Email.SendKeys(contactEmail);
        }

        /// <summary>
        /// Returns Mail field validation message
        /// </summary>
        public string GetEmailError()
        {            
            return msg_Email.Text;
        }

        /// <summary>
        /// Enters text into the Message field
        /// </summary>
        public void EnterMessage(string messsage)
        {
            input_Message.SendKeys(messsage);
        }

        /// <summary>
        /// Returns Message field validation message
        /// </summary>
        public string GetMessageError()
        {            
            return msg_Message.Text;
        }

        /// <summary>
        /// Clicks the Send button
        /// </summary>
        public void ClickSend( )
        {
            btn_Send.Click();
        }

        
    }
}

﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;

namespace FrameBaseB_Web.Pages
{
    public class PagesTester
    {
        /// Property of the logo element
        [FindsBy(How = How.Id, Using = "site-title")]
        protected IWebElement Logo { get; set; }

        /// Property of the logo element
        [FindsBy(How = How.Id, Using = "site-description")]
        protected IWebElement Tagline { get; set; }

        /// Method Check logo is displayed
        /// <returns>bool</returns>
        public bool IsLogoDisplayed()
        {
            return Logo.Displayed;
        }

        /// Method Check Tagline is Correct
        /// <returns>string</returns>
        public string IsTaglineCorrect()
        {
            return Tagline.Text;
        }


    }
}